*﻿Ubuwiki Offline*

Installation Instructions

Pre-Hardy Heron eg: Dapper Drake
# Copy ubuwiki into your documents directory.
# Open A La Carte menu editor. 
# Create a new entry, {{{ubuwiki}}}, 
# choose an icon.
# browse to find your file and its path name
# add {{{firefox}}} before the path like this {{{firefox /home/foo/Documents/ubuwiki-0.1UO.htm}}}
# close

That's all there is to it. Simplicity.

Hardy Heron and above
# Copy ubuwiki into your documents directory.
# Open preferences > main menu editor. 
# Create a new entry, {{{ubuwiki}}}
# choose an icon
# browse to find your file and its path name
# add {{{firefox}}} before the path like this {{{firefox /home/foo/Documents/ubuwiki-0.1UO.htm}}}
# close

That's all there is to it. Simplicity.

*NOTE: On some Ubuntu Installations, I have succeeded in putting the file in the usr/share/ directory, but this method involves gaining root access, permissions and the issue of ownership of computer resources. IMHO the superuser domain (sudo) should be the owner, and no company should have root access to your computer.
