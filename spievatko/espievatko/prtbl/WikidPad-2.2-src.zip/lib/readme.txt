note: I modified gadfly's sql.py to load a different sql_mar compiled grammar file.
