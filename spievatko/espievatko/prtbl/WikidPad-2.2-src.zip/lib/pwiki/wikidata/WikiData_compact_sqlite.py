from compact_sqlite.WikiData import *
