from wikidata.WikiDataManager import WikiDataManager as WikiDocument

