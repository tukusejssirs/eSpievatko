""" Constants

"""

MARSHAL_VERSION = 1
