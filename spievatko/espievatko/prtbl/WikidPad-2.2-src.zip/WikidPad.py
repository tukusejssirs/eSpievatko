import WikidPadStarter

if __name__ == "__main__":
    WikidPadStarter.main()
